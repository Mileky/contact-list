--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.2
-- Dumped by pg_dump version 14.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE contact_list_db;
--
-- Name: contact_list_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE contact_list_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Russia.1251';


ALTER DATABASE contact_list_db OWNER TO postgres;

\connect contact_list_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.address (
    id integer,
    id_recipient integer,
    address character varying(255),
    status character varying(4)
);


ALTER TABLE public.address OWNER TO postgres;

--
-- Name: contact_list; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contact_list (
    id integer,
    id_recipient integer,
    blacklist boolean
);


ALTER TABLE public.contact_list OWNER TO postgres;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.contacts (
    id_recipient integer,
    full_name character varying(255),
    birthday date,
    profession character varying(100),
    status character varying(30),
    ringtone character varying(30),
    hotkey character varying(5),
    contract_number integer,
    average_transaction_amount integer,
    discount character varying(5),
    time_to_call character varying(35),
    department character varying(40),
    "position" character varying(40),
    room_number integer,
    type character varying(15)
);


ALTER TABLE public.contacts OWNER TO postgres;

--
-- Name: phone_number; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.phone_number (
    id_phone_number integer,
    id_recipient integer,
    phone_number character varying(12),
    operator character varying(20)
);


ALTER TABLE public.phone_number OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer,
    login character varying(50),
    password character varying(60)
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.address (id, id_recipient, address, status) FROM stdin;
\.
COPY public.address (id, id_recipient, address, status) FROM '$$PATH$$/3318.dat';

--
-- Data for Name: contact_list; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contact_list (id, id_recipient, blacklist) FROM stdin;
\.
COPY public.contact_list (id, id_recipient, blacklist) FROM '$$PATH$$/3322.dat';

--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.contacts (id_recipient, full_name, birthday, profession, status, ringtone, hotkey, contract_number, average_transaction_amount, discount, time_to_call, department, "position", room_number, type) FROM stdin;
\.
COPY public.contacts (id_recipient, full_name, birthday, profession, status, ringtone, hotkey, contract_number, average_transaction_amount, discount, time_to_call, department, "position", room_number, type) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: phone_number; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.phone_number (id_phone_number, id_recipient, phone_number, operator) FROM stdin;
\.
COPY public.phone_number (id_phone_number, id_recipient, phone_number, operator) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, login, password) FROM stdin;
\.
COPY public.users (id, login, password) FROM '$$PATH$$/3321.dat';

--
-- PostgreSQL database dump complete
--

